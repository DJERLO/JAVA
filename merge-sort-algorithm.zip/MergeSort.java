class MergeSort{
    
    //Ascending Order
     void ascendSort(int[] array) {
        int arraylength = array.length;
        
        if(arraylength < 2){
            return;
        }
    
        int middle = arraylength / 2;                   //Dividing array into two part leftArray and rightArray
        int[] leftArray = new int[middle];  
        int[] rightArray = new int[arraylength - middle];
        
        for (int i = 0; i < middle; i++) {              //Assigning half of number elements on array into leftArray
            leftArray[i] = array[i];
        }
        
        for (int i = middle; i < arraylength; i++) {    //Assigning the number elements left onto Array into rightArray
            rightArray[i - middle] = array[i];
        }
        
        //Recursion
        ascendSort(leftArray);                          // Do this again but this time on leftArray
        ascendSort(rightArray);                         // Do this again and this time on rightArray
        
        //Merging here
        mergeAscend(array, leftArray, rightArray);      //This is use to merge leftArrays and rightArrays into one new sort array
    }
    
    //Descending Order    
    void descendSort(int[] array) {
        int arraylength = array.length;
        
        if(arraylength < 2){
            return;
        }
    
        int middle = arraylength / 2;
        int[] leftArray = new int[middle];
        int[] rightArray = new int[arraylength - middle];
        
        for (int i = 0; i < middle; i++) {
            leftArray[i] = array[i];
        }
        
        for (int i = middle; i < arraylength; i++) {
            rightArray[i - middle] = array[i];
        }
        
        
        //Recursion
        descendSort(leftArray);
        descendSort(rightArray);
        
        //Merging here
        mergeDescend(array, leftArray, rightArray);
        //mergeDescend(array, leftArray, rightArray);
        
       
    }    
        
        
    //Merge Two Arrays in Ascending Order    
    void mergeAscend(int[] array, int[] leftArray, int[] rightArray)  {
        int leftSize = leftArray.length;            // let us know How big leftArray is
        int rightSize = rightArray.length;          // let us know How big rightArray is
        
        int a = 0;  //For Left Array
        int b = 0;  //For Right Array
        int c = 0; //For Merging left and Right Array into one array
        
        while(a < leftSize && b < rightSize) {      //while the index a is less-than on leftArray AND  index b is less-than on rightArray -> loop
            
            if(leftArray[a] <= rightArray[b]) {     //Here We Compare leftArray indices to rightArray indices if leftArray[a] number less-than rightArray[b]
                array[c] = leftArray[a];            //If true we add the leftArray[a] and store him into single array
                a++;                                //Increment [a] to allow us to go to next index on leftArray
            }
            else {
                array[c] = rightArray[b];           //If False we add the rightArray[a] and store him into single array
                b++;                                //Increment [b] to allow us to go to next index on rightArray
            }
            c++;                                    // After sorting them out. Increment [c] to move on next index on new sorted array to store and do it again
        }                                           //Until the conditions of while loop are met 
        
        while (a < leftSize){                       //If there are number left in to leftArray -> loop
            array[c] = leftArray[a];                //Store them into new sorted array
            a++;                                    //Increment [a] allow us to go next index on leftArray
            c++;                                    //Increment [c] to move on next index on new sorted array to store and do it again until there is no number left
        }
        
         while (b < rightSize){                     //If there are number left in to rightArray -> loop
            array[c] = rightArray[b];               //Store them into new sorted array.
            b++;                                    //Increment [b] allow us to go next index on rightArray
            c++;                                    //Increment [c] to move on next index on new sorted array to store and do it again until there is no number left
        }                                           // Go back to ascendSort and see the merging here
    }
    
    //Merge Two Arrays in Descending Order    
    void mergeDescend(int[] array, int[] leftArray, int[] rightArray)  {
        int leftSize = leftArray.length;
        int rightSize = rightArray.length;
        
        int a = 0;  //For Left Array
        int b = 0;  //For Right Array
        int c = 0; //For Merging left and Right Array into one array
        
        while(a < leftSize && b < rightSize) {
            
            if(leftArray[a] >= rightArray[b]) {                 //Bonus Tip: To make sorting numbers in Ascending order just change this ">=" into this "<=""
                array[c] = leftArray[a];
                a++;
            }
            else {
                array[c] = rightArray[b];
                b++;
            }
            c++;
        }
        
        while (a < leftSize){
            array[c] = leftArray[a];
            a++;
            c++;
        }
        
         while (b < rightSize){
            array[c] = rightArray[b];
            b++;
            c++;
        }
    }


}

