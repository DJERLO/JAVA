/******************************************************************************
Merge sort is one of the most efficient sorting algorithms. It is based on the divide-and-conquer strategy. 
Merge sort continuously cuts down a list into multiple sublists until each has only one item, 
then merges those sublists into a sorted list.

Speed = O(log n)
Advantage = It is quicker for larger lists because unlike insertion and bubble sort it doesnt go through the whole list seveal times.
            It is quicker for larger lists because unlike insertion and bubble sort it doesnt go through the whole list seveal times.
            
Disadvantage = Slower comparative to the other sort algorithms for smaller tasks.
*******************************************************************************/
import java.util.Random;
public class Main
{
	public static void main(String[] args) {
		
		int maxRandomNumber = 100, setArrayLimit = 50;
		
		//Objects
		Random random =  new Random();
		MergeSort merge = new MergeSort();
		
		//Create new Array
		int[] array = new int[setArrayLimit];
		
		//Insert Random Numbers into Array
		for(int i = 0; i < array.length; i++){
		    array[i] = random.nextInt(maxRandomNumber);
		}
		
		//Print Unsorted Array
		System.out.println("Unsorted Array:");
		for(int number : array){
		    System.out.print(number + " ");
		}
		System.out.println();
		
		//Called our Method
		merge.ascendSort(array);        // Use This to Sort the Array in Ascending Order
		//merge.descendSort(array);     // Use this to Sort the Array in Descending Order
		
		//Print After Sorting using mergeSort Algorithm
		System.out.println("Sorted Array:");
		for(int number : array){
		    System.out.print(number + " ");
		}
		
	}
}
