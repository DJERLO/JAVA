class Insertion{
    
    void ascendSort(int[] array) {
        
                                                //Algorithm Behind                                            
                                                //1.For loop - Each Number with array example int[] array = {5,3}
        for(int i = 1; i < array.length; i++) {
            
            int temp = array[i];                //2. Called temp to hold temporary the  array[i] value example array[1] = 3
            
            int j = i - 1;                      //3. Called j = i - 1 or  (array[i-1]) example array[1-1] or array[0] = 5
            
            while(j >= 0 && array[j] > temp) {  //4. do a while loop and check if our array [j] is greater-than equal than zero AND our array[j] is greater-than temp
                                                // In that case our array[1-1] = 5 > array[1] = 3 which is true
               
                array[j+1] = array[j];          //5. Set array[j+1] = array [j] -> array[1-1+1] or array[1] = {5} turn to array[j] or array[0] = {3}
                                                
                j--;                            //6. Decrement the j-- or j-=1
            }
            array[j+1] = temp;                  //7. Set array[j+1] = temp -> array[1-1+1] = {5} to temp = array[i] or array[1] which is equal {3};
                                                
                                                //New Array int[] array = {3,5}
            
        }
    }
        
        void descendSort(int[] array) {
        
                                                //Algorithm Behind                                            
                                                //1.For loop - Each Number with array example int[] array = {3,5}
        for(int i = 1; i < array.length; i++) {
            
            int temp = array[i];                //2. Called temp to hold temporary the  array[i] value example array[1] = 5
            
            int j = i - 1;                      //3. Called j = i - 1 or  (array[i-1]) example array[1-1] or array[0] = 3
            
            while(j >= 0 && array[j] < temp) {  //4. do a while loop and check if our array [j] is greater-than equal than zero AND our array[j] is greater-than temp
                                                // In that case our array[1-1+1] = 5 < array[1] = 3 which is false
               
                array[j+1] = array[j];          //5. Set array[j+1] = array [j] -> array[1-1+1] = {5} turn to array[j] = {3}
                                                
                j--;                            //6. Decrement the j-- or j-=1
            }
            array[j+1] = temp;                  //7. Set array[j+1] = temp -> array[1-1+1] = {5} to temp = array[i] or array[1] which is equal {3};
                                                
                                                //New Array int[] array = {5,3}
            
        }
    }
}