/*************************************
Insertion sort is a sorting algorithm that places an unsorted element at its suitable place in each iteration.

Insertion sort works similarly as we sort cards in our hand in a card game.
We assume that the first card is already sorted then, we select an unsorted card. 
If the unsorted card is greater than the card in hand, it is placed on the right otherwise, to the left. 
In the same way, other unsorted cards are taken and put in their right place.

Speed = O(n²).
Advantage: Good For Small Sets
Disadvantage: The Bigger Sets is It Becomes more Slow

************************************/
import java.util.Random;
public class Main
{
	public static void main(String[] args) {
		
		//Variables
		int setMaxNumber = 100; // Set your max number 
		int setLimitArray = 20; // Limit of an Array
		
		//Create Random Unsorted Set of Numbers 1 - 100
		int array[] = new int[setLimitArray];
		
		//Objects
        Random random = new Random();
		Insertion insertion = new Insertion();
		
		//Insert Random Numbers into Array
		for(int i = 0; i < array.length; i++) {
		    array[i] = random.nextInt(setMaxNumber);
		}
		
		System.out.println("Before Insertion Sort Method");
		for(int numbers : array){
		    System.out.print(numbers + " ");
		}
		System.out.println();
		
		//Called Insertion Sort Method Here
		//insertion.ascendSort(array);
		//insertion.descendSort(array);
		
		System.out.println("After Insertion Sort Method:");
		for(int each : array){
		    System.out.print(each+" ");
		}
	}
}
