
package pen;

import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
       
        Pen mypen = new Pen();
        
        String brand = mypen.getBrand();
        String point = mypen.getPoint();
        String color = mypen.getColor();
        
        
        StringBuilder sb = new StringBuilder("Details About My Pen\n");
        sb.append("Brand: ");
        sb.append(brand);
        sb.append("\nPoint: ");
        sb.append(point);
        sb.append("\nColor: ");
        sb.append(color);
        
        JOptionPane.showMessageDialog(null, sb,"",-1);
       
        
    }
    
}
