/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pen;

public class Pen {
    
    private final String brand = "HBW 2000s";
    private final String point = "0.4";
    private final String color = "black";
    
    static boolean writing = false;
    
    public static boolean writing() {
        
        if (writing) {
            return true;
        } else {
           return false;
        }
        
    }

    public String getBrand() {
        return brand;
}

    public String getPoint() {
        return point;
}
    
    public String getColor() {
        return color;
}
    

}