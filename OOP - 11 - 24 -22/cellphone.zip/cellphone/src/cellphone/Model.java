
package cellphone;

public class Model {
    private final String brand = "Samsung J7 Prime";
    private final int IMEI1 = 123456789;
    private final int IMEI2 = 135682468;
    private final String model = "SM-G610F";
    
    
    public String getBrand() {
        return brand;
    }
    
    public int getIMEI1() {   
        return IMEI1;
    }
    
    public int getIMEI2() {
        return IMEI2;
    }
    
    public String getModel() {
        return model;

    }
    
    
}
