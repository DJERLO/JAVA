
package cellphone;

import javax.swing.JOptionPane;


public class Main {

    public static void main(String[] args) {
        
        Cellphone cp = new Cellphone();
        Model model = new Model();
        
        String modelPhone = model.getModel();
        int IMEI1 = model.getIMEI1();
        int IMEI2 = model.getIMEI2();
        String brand = model.getBrand();
        
        
        String status = cp.stateMode(cp.mode);
        
        StringBuilder sb = new StringBuilder("About Phone\n");
        sb.append("Model:\t ");
        sb.append(modelPhone);
        sb.append("\nBrand:\t ");
        sb.append(brand);
        sb.append("\nIMEI 1:\t ");
        sb.append(IMEI1);
        sb.append("\nIMEI 2:\t ");
        sb.append(IMEI2);
        sb.append("\nCurrent Status:\t ");
        sb.append(status);
                
        
        
        JOptionPane.showMessageDialog(null,sb,"Phone",-1);
        
        
    }
    
}
