
package cellphone;

import java.util.Random;

public class Cellphone {
    
    String[] modes = {"Wake","Sleep","Hibernate","Recharging"};
    
    Random random = new Random();
    
    int state = random.nextInt(modes.length);
    
    String mode = modes[state];
    
    public String stateMode(String mode) {
        
        String wake = modes[0];
        String sleep = modes[1];
        String hibernate = modes[2];
        String recharging = modes[3];
        
        StringBuilder sb = new StringBuilder();
        
        
        if(mode.equals(wake)) {
            String status = sb.append(mode).toString();
             return status;
        }
        else if(mode.equals(sleep)) {
           String status = sb.append(mode).toString();
             return status;
        }
        else if(mode.equals(hibernate)) {
            String status = sb.append(mode).toString();
             return status;
        }
        else if(mode.equals(recharging)) {
           String status = sb.append(mode).toString();
            return status;
        }
        return null;
    }
}