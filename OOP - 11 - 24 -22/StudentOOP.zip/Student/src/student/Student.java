package student;

public class Student {
    
    private final String name = "Jerlo F. De Leon";
    private final String section = "BSCS";
    private final String year = "2C";
    private final int age = 20;
    private final int studentId = 1237418;
    private boolean isEnrolled = true; 

public String getName() {
        return name;
    }

public String getSection() {
        return section;
    }

public String getYear() {
        return year;
    }
public int getAge() {
        return age;
    
    }
public int getId() {
        return studentId;
    
    }

public boolean status() {
    boolean Enrolled;     
    if(isEnrolled) {
        Enrolled = true;
    }else {
        Enrolled = false;
    }
        
        return Enrolled;
    
    }

}  
