package student;

import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
       Student student = new Student();
       
       String name = student.getName();
       String section = student.getSection();
       String year = student.getYear();
       int age = student.getAge();
       int studentID = student.getId();
       boolean enrolled = student.status();
       
       StringBuilder sb = new StringBuilder("Student Name: ");
       sb.append(name);
       sb.append("\nSection & Year: ");
       sb.append(section).append("-").append(year);
       sb.append("\nAge: ");
       sb.append(age);
       sb.append("\nStudent ID: ");
       sb.append(studentID);
       
       
       if (enrolled) {
           sb.append("\nStatus: ");
           sb.append("Currently Enrolled!");
       }
       else {
           sb.append("\nStatus: ");
           sb.append("Not Enrolled!");
           
       }
           
       JOptionPane.showMessageDialog(null,sb,"Student Info",-1);
       
       
    }
    
}