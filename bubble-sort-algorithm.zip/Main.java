/******************************************************************************

Bubble Sort - O(n^2) Big O Notation
Advantage = Very Good for Small Sets and Good for Medium Sets
Disadvantage = Very Slow for large sets

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    
	    //Unsorted Array sets of numbers
	    int array[] = {1,2,3,6,10,5,4,7,9,8};
	    int array2[] = {1,5,7,4,3,8,9,22,10,15,14,13,19,12,11,17,2,6,71,98,23,76,43,23,72,87,12,51,88,23,78,101,102,65,55,120,201,31,39,80};
	    //Create an Object to able to use our BubbleSort pre-define methods on BubbleSort.java
	    BubbleSort bubbleSort = new BubbleSort();
	    
	    //Called our pre-define method here
	    bubbleSort.ascending(array);
	    //bubbleSort.descending(array);
	   
	    //System.out.println(array.length);
	        
	        //We use For Each loop and Print Each Numbers
	        for(int number : array){
	            System.out.print(number+" ");
	        }
	    
	}
	

}

