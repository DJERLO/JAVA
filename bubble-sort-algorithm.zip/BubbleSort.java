/**************************************************************************************************************************

BubbleSort Algorithm                                                                                                        
Ability to swap numbers or elements inside of an unsorted array and sort them one by one in ascending or descending order
We usually compare two elements inside of unsorted array and swap them under the circumstances condition

***************************************************************************************************************************/

 class BubbleSort {
    	
	 void ascending(int array[]){
	    
	                                        //1.For loop 
	    for(int i = 0; i < array.length-1; i++){ 
	                                        //2. Nested For Loop 
	        for(int j = 0; j < array.length-1; j++){
	            
	                                        //3. Check array [J] is Greater-than to array[j+1] example for example (array[0] = 1) < (array[0+1] = 3]
	            if(array[j] > array[j+1]){  //Bonus Tip: Replace >(Greater-than) to < (less-than)  to sort them in descending
	                
	                                        //If true run this body
	                int dump = array[j];    //4. We need variable to store array[0] because we using this temporary.
	                array[j] = array[j+1];  //5. Swap array[0] to array[0+1] -> so our array[0] = 1 are now array[0+1] or array[1] = 3
	                array[j+1] = dump;      //6. Swap array[j+1] to dump which is dump -> array[0] = 1 -> so our array[0+1] or array[1] = 3 are now dump -> array[0] = 1 
	                                        //7.Back Loop Again and Repeat this process until we reach the last number of the array which is right now is 10 or our array.length
	            }
	        }
	    }
	}
	
	
	  void descending(int array[]) {
	    
	    for(int i = 0; i < array.length-1; i++){
	        for(int j = 0; j < array.length-1; j++){
	            
	            if(array[j] < array[j+1]){ 
	                int dump = array[j];
	                array[j] = array[j+1];
	                array[j+1] = dump;
	                
	                
	            }
	        }
	    }
	}
}